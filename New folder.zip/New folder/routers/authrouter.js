const express=require('express');
const Router=express.Router();
const authcontroller=require('./../Controllers/AuthController')
const viewController=require('./../Controllers/ViewController')
Router.get('/',viewController.homePage);
Router.post('/signup',authcontroller.signup);
Router.post('/login',authcontroller.logIN)
module.exports=Router;