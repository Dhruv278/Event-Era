const express=require('express');
const Router=express.Router();
const authcontroller=require('./../Controllers/AuthController')
const userController=require('./../Controllers/UserController')
Router.get('/events',authcontroller.checkToken,userController.getUsersEvents);
module.exports=Router;