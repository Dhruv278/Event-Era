const express=require('express');
const Router=express.Router();
const authcontroller=require('./../Controllers/AuthController')
const venueController=require('./../Controllers/VenueController')
Router.post('/createVenue',authcontroller.checkToken,venueController.createVenue);
Router.get('/searchbyid/:id',authcontroller.checkToken,venueController.getVenueById);
Router.get('/search',authcontroller.checkToken,venueController.getVenueByCityAndEvent);
Router.post('/book/:venueid',authcontroller.checkToken,venueController.bookVenue);
module.exports=Router;