const nodemailer=require('nodemailer')
const pug=require('pug')
const htmlToText=require('html-to-text');

module.exports=class Email{
    constructor(user,url,booking){
        this.user=user;
        this.to=user.email;
        this.Firstname=user.first_name;
        this.url=url;
    }

    newTransport(){

        return nodemailer.createTransport({
                host:process.env.GMail_HOST,
                port:process.env.GMAIL_PORT,
            auth:{
                user:process.env.MYMAIL,
                pass:process.env.MYMAIL_PASSWORD
            }
        })
    }
  async  send(templet,subject){
         const html=pug.renderFile(`${__dirname}/../views/emails/${templet}.pug`,{
             first_name:this.first_name,
             url:this.url,
             subject
         })
        const mailOption={
            from:`${process.env.MYMAIL}`,
            to:this.to,
            subject,
            html,
            text:htmlToText.fromString(html)
            // html
        }
        // console.log('inside email 2')
    // send mail
   console.log('working')
   await this.newTransport().sendMail(mailOption)
   
    


    }
async welcomeMail(){
 await   this.send("Welcome",'Thank you for join with US')
//  console.log('inside email 1')
}
async passwordEmail(){
    await this.send('ForgotPaswword','Reset Password')
}
async verificationMail(){
    await this.send("ForgotPaswword",'Verifiction Account')
}
}
