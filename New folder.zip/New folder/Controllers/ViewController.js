// const User=require('./../Schema/UserSchema');
// 
const User = require('../schema/UserSchema');
const Bookings =require('./../Schema/BookingSchema');
const Venue=require('./../Schema/VenueSchema');


exports.homePage=async(req,res)=>{
   const result= await User.find()
    res.render('main');
}