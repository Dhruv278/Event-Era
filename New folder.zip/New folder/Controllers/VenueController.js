const User = require('../schema/UserSchema');
const catchAsync = require('../errorHandling/cathError');
const Email = require('./email')
const Venue=require('./../Schema/VenueSchema')
const jwt = require('jsonwebtoken');
const Bookings=require('./../Schema/BookingSchema')
const appError = require('../errorHandling/ErrorFormate')


exports.getVenueById=catchAsync(async(req,res,next)=>{
    const id=req.params.id;
    const venue=await Venue.findById(id);
    res.status(200).json({
        venue
    })
})

exports.createVenue=catchAsync(async(req,res,next)=>{
    const venue=await Venue.create({
        name:req.body.name,
        price:req.body.price,
        max_capacity:req.body.max_capacity,
        description:req.body.description,
        events:req.body.events,
        city:req.body.city,
        images:req.body.images

    })

    res.status(200).json({
        status:"success",
        venue
    })
})

exports.getVenueByCityAndEvent=catchAsync(async(req,res,next)=>{
    console.log('working')
  const city =req.user.city;
  const event=req.body.event;
   console.log(city,event)
  const venues=await Venue.find({city:city, events: { "$in" : [`${event}`]}})
  console.log(venues);

  res.status(200).json({
      venues
  })
}) 


exports.bookVenue=catchAsync(async(req,res,next)=>{

    const userid=req.user._id;
    const venueid=req.params.venueid;
    const d= new Date(req.body.date)
   
    
    const checkbook=await Bookings.find({bookingDate:d,venue:venueid});
    console.log(checkbook)
    if(checkbook.length!=0){
        return next(new appError('Venue is already bokked on this day',500))
    }
    const booking=await Bookings.create({
    event_name:req.body.event_name,
    venue:venueid,
    user:userid,
    bookingDate:d,
    })
   req.user.booking.push(booking._id);
   await req.user.save()

   await new Email('')
    res.status(200).json({
        booking
    })

})