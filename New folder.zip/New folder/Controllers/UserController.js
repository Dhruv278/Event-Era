const User = require('../schema/UserSchema');

const catchAsync = require('../errorHandling/cathError');
const Email = require('./email')
const jwt = require('jsonwebtoken');
const appError = require('../errorHandling/ErrorFormate')

exports.getUsersEvents=catchAsync(async(req,res,next)=>{
    console.log('hiiiiiiiiii')
    const userid=req.user._id;
  console.log(userid)
    const UsersEvents=await User.findById(userid).populate('booking')

    res.status(200).json({
        UsersEvents
    })
})